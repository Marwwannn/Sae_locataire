package modele;

public class Contenir {
	private static String idCaution;
	private static String dateDebutContrat;


	public Contenir() {
	}

	public String getIdCaution() {
		return idCaution;
	}

	public String getDateDebutContrat() {
		return dateDebutContrat;
	}
}
